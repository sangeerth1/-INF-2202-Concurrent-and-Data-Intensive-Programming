#include <iostream>
#include <upcxx/upcxx.hpp>
#include <atomic>

using namespace std;

#define ARRAY_SIZE 20





template <class T>
ConcurrentQueue<T>::ConcurrentQueue() {


	

	data = upcxx::new_array<atomic<T>>(ARRAY_SIZE);
	tail = upcxx::new_<atomic<int>>(0);
	head = upcxx::new_<atomic<int>>(0);



  // Implement queue constructor.
}
template <class T>
int ConcurrentQueue<T>::enq(T value_t) 
{	
	

		
	int element;
	int mustWakeEnqueuers;

	T result = 0;	

	atomic<T> *element_next;
	atomic<int> *tail_loc;


	// downcast tail to int 
	tail_loc = tail.local();

	element = tail_loc->load();  // 

	element_next =  &data.local()[element+1];

	mustWakeEnqueuers = element_next->compare_exchange_strong(result,value_t,memory_order_release,memory_order_relaxed);

	if(mustWakeEnqueuers != true){

		mustWakeEnqueuers =  tail.local()->compare_exchange_strong(element,element+1,memory_order_release,memory_order_relaxed);
	}	
	


	

	while(mustWakeEnqueuers != true);

	// update the tail pointer to next
	tail.local()->compare_exchange_strong(element,element+1,memory_order_release,memory_order_relaxed);
	return 1;




}	   


  // Implement queue enqueue.

template <class T>
int ConcurrentQueue<T>::deq(T* buf) {


	atomic<T> *mustWakeDequeuers;
	atomic<int> *capasity;

	int element; 
	mustWakeDequeuers = data.local();

	
	// fetch a local pointer to the head 
	capasity = head.local(); 
	element = capasity->load();  // load the atomic value

	if(mustWakeDequeuers[element+1] == 0){
		return 0; 
	}



    while(!capasity->compare_exchange_strong(element, element+1,memory_order_release,memory_order_relaxed));

   		*buf = mustWakeDequeuers[element+1];
   		mustWakeDequeuers[element+1] = 0;
   		return 1;




}




























  // Implement queue deque.

