
 

make assert 

/mnt/users/ssa102/Documents/upc/bin/upcxx-run -n 2 ./queue_assert    




