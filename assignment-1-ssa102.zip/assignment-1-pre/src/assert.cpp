#include "queue.h"
#include <iostream>
#include <upcxx/upcxx.hpp>

#define TEST_CYCLES 1

using namespace std;

void sequential_assert_queue() {
  cout << "Running sequential test with one process... \n";

  int test_ints [10] = {1,2,3,4,5,6,7,8,9,10};
  int deque_int = -1;
  bool passed = true;

  ConcurrentQueue<int> sequential_queue_int;

  cout << "Running sequential test for type: <int>... ";
  for (int i = 0; i < 10; i++) {
    sequential_queue_int.enq(test_ints[i]);
  }
  for (int i = 0; i < 10; i++) {
    sequential_queue_int.deq(&deque_int);
    if (deque_int != test_ints[i]) {
      cout << "FAILED\n";
      cout << "Sequential deque failed <int> FIFO test: Expected (" << test_ints[i] << ") recieved (" << deque_int << ").\n";
      passed = false;
      break;
    }
  }

  if (passed) {
    cout << "PASSED!\n";
  }

  cout << "Running sequential test for type: <char>... ";

  char test_chars [10] = {'A','B','C','D','E','F','g','h','i','J'};
  char deque_char = 'a';
  passed = true;

  ConcurrentQueue<char> sequential_queue_char;

  for (int i = 0; i < 10; i++) {
    sequential_queue_char.enq(test_chars[i]);
  }
  for (int i = 0; i < 10; i++) {
    sequential_queue_char.deq(&deque_char);
    if (deque_char != test_chars[i]) {
      cout << "FAILED\n";
      cout << "Sequential deque failed <char> FIFO test: Expected (" << test_chars[i] << ") recieved (" << deque_char << ").\n";
      passed = false;
      break;
    }
  }
  if (passed) {
    cout << "PASSED!\n";
  }
  cout << "Running test with mixed enq and deq operations... ";

  ConcurrentQueue<int> mixed_queue;

  mixed_queue.enq(test_ints[0]);
  mixed_queue.enq(test_ints[1]);
  mixed_queue.enq(test_ints[6]);

  mixed_queue.deq(&deque_int);
  if (deque_int != test_ints[0]) {
    cout << "FAILED \n";
    return;
  }

  mixed_queue.enq(test_ints[7]);

  mixed_queue.deq(&deque_int);
  if (deque_int != test_ints[1]) {
    cout << "FAILED \n";
    return;
  } else {
    cout << "PASSED!\n";
    return;
  }
}

int main(int argc, char* argv[])
{
  upcxx::init();
  int num_workers = upcxx::rank_n();
  upcxx::team &local_team = upcxx::local_team();

  if (local_team.rank_n() != num_workers) {
    cout << "Detected (" << num_workers << ") world processes but only (" << local_team.rank_n() << ") processes in local team. \n";
    cout << "Please ensure all UPC++ subprocesses are running on the same host.\n";
    exit(-1);
  }

  // Have rank 0 make a sequential test alone.
  if (!local_team.rank_me()) {
    sequential_assert_queue();
  }
  if (num_workers < 2) {
    cout << "Skipping further tests since number of processes is 1... FINSHED\n";
    exit(1);
  }
  // Wait for sequential test to finish.
  upcxx::barrier(local_team);
  cout << "Multiple processes detected, running concurrent test...\n";
  if (!local_team.rank_me()) {
    cout << "Running queue assertion tests with " << num_workers << " worker(s)... ";
  }
  // Backchannel variables used to verify the correctness of concurrent operations.
  upcxx::global_ptr<atomic_int> expected_global = nullptr;
  upcxx::global_ptr<atomic_int> result_global = nullptr;
  upcxx::global_ptr<ConcurrentQueue<int>> queue_global = nullptr;

  // Initalize the atomic ints in rank 0 and share it with the other processes
  if (!local_team.rank_me()) {
    expected_global = upcxx::new_<atomic_int>(0);
    result_global = upcxx::new_<atomic_int>(0);
    queue_global = upcxx::new_<ConcurrentQueue<int>>();
  }
  upcxx::barrier(local_team);

  // Ensure all processes have the same references to backchannel values.
  expected_global = upcxx::broadcast(expected_global,0,local_team).wait();
  result_global = upcxx::broadcast(result_global,0,local_team).wait();
  queue_global = upcxx::broadcast(queue_global,0,local_team).wait();

  assert(expected_global.is_local());
  assert(result_global.is_local());
  assert(queue_global.is_local());

  atomic_int* expected_local = expected_global.local();
  atomic_int* result_local = result_global.local();
  ConcurrentQueue<int>* queue_local = queue_global.local();

  upcxx::barrier(local_team);
  // Split processes into producers and consumers.

  if (!(local_team.rank_me() % 2)) {
    // Producer
    for (int i = TEST_CYCLES; i > 0; i--) {
      *expected_local += i;
      queue_local->enq(i);
    }
  } else {
    // Consumer
    for (int i = TEST_CYCLES; i > 0; i--) {
      int dequed_val = -1;
      int err = queue_local->deq(&dequed_val);
      while (err==-1) {
        err = queue_local->deq(&dequed_val);
      }
      *result_local += dequed_val;
    }
  }
  upcxx::barrier(local_team);
  // Check for correct result.
  if (!local_team.rank_me()) {
    auto expected_final = expected_local->load();
    auto result_final = result_local->load();
    if (expected_final == result_final) {
      cout << "PASSED!\n";
    } else {
      cout << "FAILED\n";
      cout << "Concurrent test failed: expected total result (" << expected_final << ") but result was (" << result_final << ")\n";
    }
  }
  upcxx::finalize();
}
