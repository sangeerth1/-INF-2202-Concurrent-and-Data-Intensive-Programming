#include <iostream>
#include <upcxx/upcxx.hpp>
#include <atomic>

using namespace std;

#define ARRAY_SIZE 20  // define array size as 20





template <class T>
ConcurrentQueue<T>::ConcurrentQueue() {


	// initialize array,head and tail as atomic

	data = upcxx::new_array<atomic<T>>(ARRAY_SIZE);
	tail = upcxx::new_<atomic<int>>(0);
	head = upcxx::new_<atomic<int>>(0);



  // Implement queue constructor.
}
template <class T>
int ConcurrentQueue<T>::enq(T value_t) 
{	
	

		
	int element;  // initalize element 
	int sucess;   // initalize sucess

	T result = 0;	
	// initialize element_next and tail_loc as atomic
	atomic<T> *element_next;
	atomic<int> *tail_loc;


	// fetch a local pointer to tail
	tail_loc = tail.local();

	element = tail_loc->load();  //   fetch out the value to the local pointer  

	element_next =  &data.local()[element+1];

	sucess = element_next->compare_exchange_strong(result,value_t,memory_order_release,memory_order_relaxed);   

	if(sucess != true){   // if sucess is not true 

		sucess =  tail.local()->compare_exchange_strong(element,element+1,memory_order_release,memory_order_relaxed); // increment tail for check for next
	}	
	


	

	while(sucess != true);

	// update the tail pointer 
	tail.local()->compare_exchange_strong(element,element+1,memory_order_release,memory_order_relaxed);
	return 1;




}	   


  

template <class T>
int ConcurrentQueue<T>::deq(T* buf) {

	// initialize data loc and head loc as atomic 
	atomic<T> *data_loc;
	atomic<int> *head_loc;

	int element;   // initialize element
	data_loc = data.local();  // fetch a local pointer to the data

	
	// fetch a local pointer to the head 
	head_loc = head.local(); 
	element = head_loc->load();  // load fetch the  value

	if(data_loc[element+1] == 0){
		return 0; 
	}



    while(!head_loc->compare_exchange_strong(element, element+1,memory_order_release,memory_order_relaxed));
    	// dequeue worker to buffer
   		*buf = data_loc[element+1];
   		data_loc[element+1] = 0;
   		return 1;




}




























 

