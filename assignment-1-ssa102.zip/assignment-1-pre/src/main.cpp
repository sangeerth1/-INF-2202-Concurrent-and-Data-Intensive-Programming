#include "queue.h"
int main(int argc, char const *argv[]) {
  
  /* Implement your own test code here */




	

}
