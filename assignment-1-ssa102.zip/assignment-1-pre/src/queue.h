#ifndef _CONCURRENT_QUEUE_H_
#define _CONCURRENT_QUEUE_H_
#include <upcxx/upcxx.hpp>
#include <iostream>
#include <atomic>

using namespace std;
template <class T>
class Record {
};









template <class T>
class ConcurrentQueue {
public:

  upcxx::global_ptr<atomic<int>>head;
  upcxx::global_ptr<atomic<int>>tail;
  upcxx::global_ptr<atomic<T>>data;

 


  ConcurrentQueue<T>();  /*
   * A total insertion function - returns without blocking.
   * Adds value_t to the queue. Returns 1 on success and -1 on failure.
   */
   int enq(T value_t);
  /*
   * A total retrieval function - returns without blocking.
   * Places the first element in the queue into buf. Returns 1 on success and
   * -1 if the queue is empty.
   */
  int deq(T* buf);
};

/* This is a hack to get around how c++ handles template types */
#include "queue.cpp"
#endif
