K_features = 2 
NUM_USERS = 6040
LAMBDA = 0.05    # lambda value for gradient decent
NUM_STEPS = 100 
STEP_SIZE = 0.02 
eta = 0.02 


