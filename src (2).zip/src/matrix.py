from config import*
from mpi4py import MPI 
import sys 
import math 
import queue
import random
import numpy as np  




class MatrixData():
    def __init__(self):
        self.comm = MPI.COMM_WORLD  # used as communicator 
        self.rank = self.comm.Get_rank()
        #print('my_rank is',rank)
        self.size = self.comm.Get_size()
        self.user_map = {}
        self.num_ranks = 0 
        self.omega_queue = []
        self.data_item = {} 
        self.NUM_ITEMS = 2
        self.NUM_USERS= 6040 
        self.V = None 
        self.U = None 
        self.timer = 2 
        self.iterations = 100
        self.worker = [i for i in range(self.size)]
        self.LAMBDA = 0.05
        self.STEP_SIZE = 0.02 
        self.omega_data = {}
        self.RAWS = 120
        #self.TAG_FOR_QUEUES = 410 
        self.list = []
       
        
        

    def get_owner_rank_by_index(self,index):
        return index % self.comm.Get_size() 
        

    # start for rank 0 , gives each of them core 
    def insert_value(self,user,movie,rating):
        tmp_data = {user: {movie: rating}}
        rank = self.get_owner_rank_by_index(user)
        self.comm.isend(tmp_data,rank) 

    def RMSE(self,obs,est): # calculates Root mean square error 
        return np.sqrt(np.square(np.subtract(obs,est))).mean()


  
        
    # Initialize the V_vector, 
    def V_vector(self): 
        
        
        array = np.empty([0,K_features])

        for _ in range(0,NUM_USERS):

            rand_1 = random.uniform(0,1/math.sqrt(K_features))  # calculate the V vector by using the formula 
            rand_2 = random.uniform(0,1/math.sqrt(K_features)) 
            array = np.append(array,[ [rand_1,rand_2] ], axis = 0) 


        self.V = array    

        print(array,"\n")
        
    def U_vector(self): 
        
        
        array = np.empty([0,K_features])

        for _ in range(0,NUM_USERS):

            rand_1 = random.uniform(0,1/math.sqrt(K_features))  
            rand_2 = random.uniform(0,1/math.sqrt(K_features)) 
            array = np.append(array,[ [rand_1,rand_2] ], axis = 0)  

        self.U = array    

        #print(array,"\n")
            
        return array

    

    
    def distrubute(self): 
         
        with open("tree.txt") as f:  
            print("Reading SGD data...\n")
            for line in f: 
            ## split the curr_line 
                curr_line = line.split()  

                user = int(curr_line[0]) 
                movie = int(curr_line[1])
                rating = float(curr_line[2]) 

                item = [user,movie,rating]
               
                if movie > self.NUM_ITEMS: 
                    self.NUM_ITEMS = movie

                self.list = self.omega_data[self.rank] if self.omega_data else []
            
               
                self.list.append(user)
                self.omega_data[self.rank] = self.list 
                     

                if self.rank == 0: 
                   data_item = self.data_item[user] if user in self.data_item else {}
                   data_item[movie] = rating
                   self.data_item[user] = data_item

                    
                

            matrixdata.insert_value(user,movie,rating)
            print(self.data_item)

    def last_signal(self):  # sending done signal 
        for x in range(1,self.size):
            self.comm.send("done", dest = x)    

    def assign_rows(self):
        item = self.comm.recv(source = 0,tag = self.RAWS)
        
        while item != "finished":
            user = item[0]
            movie = item[1]
            rating = item[2] 
        


        local_data = self.data_item[user] if user in self.data_item else{}

        local_data[movie] = rating 
        self.data_item[user] = local_data
    
    


    
          
    def distrubute_columns(self):
        if self.rank == 0:
            
            for j,h_j in enumerate(self.V):
                vector = [j,h_j]
                if j % self.size == self.rank:
                    self.omega_queue.append(vector)
                else:
                    self.comm.send(vector,dest = self.rank) 
            self.last_signal()
    
        else:
            data = self.comm.recv(source = 0)
            while data != "done":
                self.omega_queue.append(data) 
                
                data = self.comm.recv(source = 0)

                
    
    def calculate_SGD(self,STEP_SIZE,LAMBDA) :

        if self.omega_queue:
            hj = self.omega_queue.pop(0)  # pop the queue 
            
            for i in self.data_item:     # iterating over data item
                if hj[0] in self.data_item[i]: # initialize as index i 
                    
                
                    


                    x_i = self.SGD_update_w_i (self.data_item[i][hj],self.U,self.V,STEP_SIZE,LAMBDA)     # update the sgd update by rating U Vector Vector and Step size and Lambda
                    h_j = self.SGD_update_h_j(self.data_item[i][hj],self.U,self.V,STEP_SIZE,LAMBDA)   # update the sgd update by rating U vector V vector and Step size and lambda 

                if self.size == 1: 
                    self.omega_queue.append([i,hj])    # append the omega queue with i and hj 

                else: 
                    r = np.random.choice(self.worker) 
                    self.comm.send([i,hj],dest = r) # send to the random worker 

    def SGD_update_w_i(self,A_ij,w_i,h_j,s_t,lambda_x): # inheritance the SGD update from the precode 
        w_i_dot=w_i+s_t*((A_ij-np.matmul(w_i,h_j))*h_j - lambda_x*w_i)
        return w_i_dot

    def SGD_update_h_j(self,A_ij,w_i,h_j,s_t,lambda_x): # inheritance the SGD update from the precode
        h_j_dot=h_j+s_t*((A_ij-np.matmul(w_i,h_j))*w_i - lambda_x*h_j)
        return h_j_dot 


    def main(self):
        self.comm = MPI.COMM_WORLD   # used as communicator 
        matrixdata.V_vector()        # calling on V_vector
        matrixdata.distrubute()
        matrixdata.distrubute_columns() 
        matrixdata.calculate_SGD(STEP_SIZE,LAMBDA)
        matrixdata.assign_rows()
        self.comm.Barrier()
        matrixdata.U_vector()


       

        if self.rank == 0: 
            print('my_rank is',self.comm.rank)
            print("sending ...")
            matrixdata.distrubute_columns()
          

        self.comm.Barrier()
        MPI.Finalize()       
    


if __name__ == "__main__": 
    matrixdata = MatrixData()
    matrixdata.main()
    